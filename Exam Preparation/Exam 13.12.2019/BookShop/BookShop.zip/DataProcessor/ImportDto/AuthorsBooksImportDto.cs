﻿namespace BookShop.DataProcessor.ImportDto
{
    public class AuthorsBooksImportDto
    {
        public string Id { get; set; }
    }
}
